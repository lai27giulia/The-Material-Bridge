"use client"

import { createContext, useContext, useState, useCallback, ReactNode } from "react"

interface AudioContextType {
  isMuted: boolean
  toggleMute: () => void
  playClick: () => void
  playHover: () => void
}

const AudioContext = createContext<AudioContextType | undefined>(undefined)

// Web Audio API for industrial sounds
function createMetallicClick(): void {
  if (typeof window === "undefined") return
  
  try {
    const audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
    
    // Create oscillator for metallic click
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()
    
    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)
    
    oscillator.type = "square"
    oscillator.frequency.setValueAtTime(800, audioContext.currentTime)
    oscillator.frequency.exponentialRampToValueAtTime(200, audioContext.currentTime + 0.05)
    
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.1)
    
    oscillator.start(audioContext.currentTime)
    oscillator.stop(audioContext.currentTime + 0.1)
  } catch {
    // Audio not supported or blocked
  }
}

function createHissSound(): void {
  if (typeof window === "undefined") return
  
  try {
    const audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
    
    // Create white noise for hydraulic hiss
    const bufferSize = audioContext.sampleRate * 0.05
    const buffer = audioContext.createBuffer(1, bufferSize, audioContext.sampleRate)
    const data = buffer.getChannelData(0)
    
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.02
    }
    
    const source = audioContext.createBufferSource()
    const gainNode = audioContext.createGain()
    
    source.buffer = buffer
    source.connect(gainNode)
    gainNode.connect(audioContext.destination)
    
    gainNode.gain.setValueAtTime(0.05, audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.05)
    
    source.start(audioContext.currentTime)
  } catch {
    // Audio not supported or blocked
  }
}

export function AudioProvider({ children }: { children: ReactNode }) {
  const [isMuted, setIsMuted] = useState(true) // Default: muted

  const toggleMute = useCallback(() => {
    setIsMuted(prev => !prev)
  }, [])

  const playClick = useCallback(() => {
    if (!isMuted) {
      createMetallicClick()
    }
  }, [isMuted])

  const playHover = useCallback(() => {
    if (!isMuted) {
      createHissSound()
    }
  }, [isMuted])

  return (
    <AudioContext.Provider value={{ isMuted, toggleMute, playClick, playHover }}>
      {children}
    </AudioContext.Provider>
  )
}

export function useAudio() {
  const context = useContext(AudioContext)
  if (!context) {
    throw new Error("useAudio must be used within an AudioProvider")
  }
  return context
}
