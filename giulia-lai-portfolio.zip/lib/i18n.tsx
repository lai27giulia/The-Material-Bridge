"use client"

import { createContext, useContext, useState, useEffect, ReactNode } from "react"

type Language = "es" | "en"

interface I18nContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const translations: Record<Language, Record<string, string>> = {
  es: {
    // Hero
    "hero.title": "Futura Ingeniera de Materiales",
    "hero.subtitle": "Investigadora UX Industrial",
    "hero.uvp": "Reduzco los desechos en procesos de soldadura transformando la complejidad técnica en protocolos a medida humana.",
    
    // Case Study
    "case.title": "Transformación: Del Caos a la Eficiencia",
    "case.context": "Soldadura estructural en bastidores industriales",
    
    // Hotspots
    "hotspot.technical.label": "Punto Técnico",
    "hotspot.technical.problem": "Engrosamiento del Grano",
    "hotspot.technical.consequence": "La estructura cristalina se engrosa en la zona afectada térmicamente (ZAT), reduciendo drásticamente la tenacidad y la resistencia a fatiga de la unión.",
    "hotspot.technical.solution": "Control térmico riguroso y selección de aleaciones de grano fino estabilizado para limitar el crecimiento durante el ciclo térmico.",
    
    "hotspot.process.label": "Punto de Proceso",
    "hotspot.process.problem": "Precipitación de Carburos",
    "hotspot.process.consequence": "En los aceros inoxidables, el cromo migra hacia los bordes de grano formando carburos, causando corrosión intergranular y fallo prematuro.",
    "hotspot.process.solution": "Uso de aceros de bajo carbono (grado L) o estabilizados con Ti/Nb, y tratamiento térmico post-soldadura.",
    
    "hotspot.human.label": "Punto Humano",
    "hotspot.human.problem": "Tensiones Internas (SCC)",
    "hotspot.human.consequence": "Las tensiones residuales combinadas con ambientes corrosivos causan agrietamiento por corrosión bajo tensión, invisible hasta el fallo catastrófico.",
    "hotspot.human.solution": "Alivio de tensiones post-soldadura y protocolo visual UX para operadores que destaca los puntos de control críticos.",
    
    // Technical Evidence
    "evidence.title": "Evidencia Científica",
    "evidence.subtitle": "Análisis del Grano y Microdureza",
    "evidence.micrograph": "Micrografía: Estructura martensítica con grietas intergranulares",
    "evidence.diagram": "Curva Tensión-Deformación: Comportamiento mecánico del material",
    
    // Bio
    "bio.title": "El Puente",
    "bio.description": "Traduzco la ciencia de los metales en protocolos operativos intuitivos para eliminar errores, desechos y estrés en producción.",
    
    // CTA
    "cta.question": "¿Problemas de calidad?",
    "cta.action": "Resolviémoslos en LinkedIn",
    
    // Ticker
    "ticker.text": "CERO AMBIGÜEDAD • MÁXIMA EFICIENCIA • PROTOCOLOS HUMANOS • CIENCIA DE MATERIALES",
    
    // Audio
    "audio.enable": "Activar Audio Industrial",
    "audio.disable": "Silenciar",
    
    // Footer
    "footer.privacy": "Privacidad por Diseño: Sin cookies, sin seguimiento, solo ciencia.",
    "footer.download": "Descargar CV",
  },
  en: {
    // Hero
    "hero.title": "Future Materials Engineer",
    "hero.subtitle": "Industrial UX Researcher",
    "hero.uvp": "Reducing weld waste by transforming technical complexity into human-centered protocols.",
    
    // Case Study
    "case.title": "Transformation: From Chaos to Efficiency",
    "case.context": "Structural welding on industrial frames",
    
    // Hotspots
    "hotspot.technical.label": "Technical Point",
    "hotspot.technical.problem": "Grain Coarsening",
    "hotspot.technical.consequence": "The crystalline structure coarsens in the heat-affected zone (HAZ), drastically reducing toughness and fatigue resistance of the joint.",
    "hotspot.technical.solution": "Rigorous thermal control and selection of fine-grain stabilized alloys to limit growth during the thermal cycle.",
    
    "hotspot.process.label": "Process Point",
    "hotspot.process.problem": "Carbide Precipitation",
    "hotspot.process.consequence": "In stainless steels, chromium migrates to grain boundaries forming carbides, causing intergranular corrosion and premature failure.",
    "hotspot.process.solution": "Use of low-carbon steels (L-grade) or Ti/Nb stabilized grades, and post-weld heat treatment.",
    
    "hotspot.human.label": "Human Point",
    "hotspot.human.problem": "Internal Stresses (SCC)",
    "hotspot.human.consequence": "Residual stresses combined with corrosive environments cause stress corrosion cracking, invisible until catastrophic failure.",
    "hotspot.human.solution": "Post-weld stress relief and UX visual protocol for operators highlighting critical checkpoints.",
    
    // Technical Evidence
    "evidence.title": "Scientific Evidence",
    "evidence.subtitle": "Grain Analysis and Microhardness",
    "evidence.micrograph": "Micrograph: Martensitic structure with intergranular cracks",
    "evidence.diagram": "Stress-Strain Curve: Mechanical behavior of the material",
    
    // Bio
    "bio.title": "The Bridge",
    "bio.description": "I translate materials science into intuitive operating protocols to eliminate errors, waste, and stress in production.",
    
    // CTA
    "cta.question": "Quality issues?",
    "cta.action": "Let's solve them on LinkedIn",
    
    // Ticker
    "ticker.text": "ZERO AMBIGUITY • MAXIMUM EFFICIENCY • HUMAN PROTOCOLS • MATERIALS SCIENCE",
    
    // Audio
    "audio.enable": "Enable Industrial Audio",
    "audio.disable": "Mute",
    
    // Footer
    "footer.privacy": "Privacy by Design: No cookies, no tracking, just science.",
    "footer.download": "Download CV",
  },
}

const I18nContext = createContext<I18nContextType | undefined>(undefined)

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("es")

  useEffect(() => {
    // Detect browser language
    const browserLang = navigator.language.slice(0, 2)
    if (browserLang === "en") {
      setLanguage("en")
    } else {
      setLanguage("es")
    }
  }, [])

  const t = (key: string): string => {
    return translations[language][key] || key
  }

  return (
    <I18nContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </I18nContext.Provider>
  )
}

export function useI18n() {
  const context = useContext(I18nContext)
  if (!context) {
    throw new Error("useI18n must be used within an I18nProvider")
  }
  return context
}
