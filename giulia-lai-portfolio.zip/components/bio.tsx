"use client"

import { useI18n } from "@/lib/i18n"
import { motion } from "framer-motion"

export function Bio() {
  const { t } = useI18n()

  return (
    <section className="border-b-4 border-foreground bg-dirty-white industrial-grid">
      <div className="max-w-4xl mx-auto px-4 md:px-8 py-16 md:py-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          {/* Bridge Icon */}
          <div className="flex justify-center mb-8">
            <div className="flex items-center gap-2">
              <div className="h-1 w-12 md:w-24 bg-foreground" />
              <div className="w-8 h-8 md:w-12 md:h-12 border-4 border-foreground bg-accent rotate-45" />
              <div className="h-1 w-12 md:w-24 bg-foreground" />
            </div>
          </div>

          <h2 className="font-sans text-3xl md:text-5xl font-black uppercase tracking-tight mb-6">
            {t("bio.title")}
          </h2>
          
          <p className="font-sans text-lg md:text-xl leading-relaxed max-w-2xl mx-auto text-balance">
            {t("bio.description")}
          </p>
        </motion.div>
      </div>
    </section>
  )
}
