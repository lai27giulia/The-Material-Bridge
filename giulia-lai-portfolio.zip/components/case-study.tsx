"use client"

import { useState } from "react"
import Image from "next/image"
import { useI18n } from "@/lib/i18n"
import { useAudio } from "@/lib/audio"
import { motion, AnimatePresence } from "framer-motion"
import { X, Wrench, Cog, User } from "lucide-react"

type HotspotId = "technical" | "process" | "human"

interface HotspotConfig {
  id: HotspotId
  icon: React.ReactNode
  position: { top: string; left: string }
  color: string
}

const hotspots: HotspotConfig[] = [
  {
    id: "technical",
    icon: <Wrench className="w-4 h-4" />,
    position: { top: "30%", left: "25%" },
    color: "bg-accent",
  },
  {
    id: "process",
    icon: <Cog className="w-4 h-4" />,
    position: { top: "55%", left: "50%" },
    color: "bg-muted",
  },
  {
    id: "human",
    icon: <User className="w-4 h-4" />,
    position: { top: "40%", left: "75%" },
    color: "bg-rust",
  },
]

export function CaseStudy() {
  const { t } = useI18n()
  const { playClick, playHover } = useAudio()
  const [activeHotspot, setActiveHotspot] = useState<HotspotId | null>(null)

  const handleHotspotClick = (id: HotspotId) => {
    playClick()
    setActiveHotspot(activeHotspot === id ? null : id)
  }

  return (
    <section className="border-b-4 border-foreground bg-background">
      {/* Section Header */}
      <div className="border-b-4 border-foreground px-4 md:px-8 py-6">
        <h2 className="font-sans text-2xl md:text-4xl font-black uppercase tracking-tight">
          {t("case.title")}
        </h2>
        <p className="font-mono text-sm md:text-base text-muted mt-2">
          {t("case.context")}
        </p>
      </div>

      {/* Image Container with Hotspots */}
      <div className="relative">
        <div className="relative w-full aspect-video md:aspect-[21/9] overflow-hidden border-b-4 border-foreground">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/saldatura1-kG5VQDP73McA6doPohCOQhsLCZyAEY.jpg"
            alt="Industrial welding process showing torch applying material to metal surface"
            fill
            className="object-cover"
            priority
          />
          
          {/* Industrial overlay grid */}
          <div className="absolute inset-0 industrial-grid opacity-20" />

          {/* Hotspots */}
          {hotspots.map((hotspot) => (
            <button
              key={hotspot.id}
              onClick={() => handleHotspotClick(hotspot.id)}
              onMouseEnter={playHover}
              style={{
                top: hotspot.position.top,
                left: hotspot.position.left,
              }}
              className={`absolute transform -translate-x-1/2 -translate-y-1/2 w-12 h-12 md:w-14 md:h-14 ${hotspot.color} border-4 border-foreground flex items-center justify-center cursor-pointer transition-transform hover:scale-110 ${
                activeHotspot === hotspot.id ? "scale-110 ring-4 ring-accent" : "hotspot-pulse"
              }`}
              aria-label={t(`hotspot.${hotspot.id}.label`)}
            >
              <span className="text-background">{hotspot.icon}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Hotspot Details Panel */}
      <AnimatePresence mode="wait">
        {activeHotspot && (
          <motion.div
            key={activeHotspot}
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden border-b-4 border-foreground"
          >
            <div className="p-4 md:p-8 bg-dirty-white">
              <div className="max-w-4xl mx-auto">
                {/* Header with close button */}
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <span className="inline-block px-3 py-1 font-mono text-xs font-bold bg-foreground text-background uppercase mb-2">
                      {t(`hotspot.${activeHotspot}.label`)}
                    </span>
                    <h3 className="font-sans text-xl md:text-3xl font-black uppercase">
                      {t(`hotspot.${activeHotspot}.problem`)}
                    </h3>
                  </div>
                  <button
                    onClick={() => {
                      playClick()
                      setActiveHotspot(null)
                    }}
                    className="p-2 border-2 border-foreground hover:bg-foreground hover:text-background transition-colors"
                    aria-label="Close"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Content Grid */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Problem / Consequence */}
                  <motion.div
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.1 }}
                    className="brutal-border p-4 md:p-6 bg-background"
                  >
                    <span className="inline-block px-2 py-1 font-mono text-xs bg-destructive text-destructive-foreground uppercase mb-3">
                      Consequence
                    </span>
                    <p className="font-sans text-sm md:text-base leading-relaxed">
                      {t(`hotspot.${activeHotspot}.consequence`)}
                    </p>
                  </motion.div>

                  {/* Solution */}
                  <motion.div
                    initial={{ x: 20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="brutal-border-accent p-4 md:p-6 bg-background"
                  >
                    <span className="inline-block px-2 py-1 font-mono text-xs bg-accent text-accent-foreground uppercase mb-3">
                      Solution
                    </span>
                    <p className="font-sans text-sm md:text-base leading-relaxed">
                      {t(`hotspot.${activeHotspot}.solution`)}
                    </p>
                  </motion.div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  )
}
