"use client"

import { useI18n } from "@/lib/i18n"
import { useAudio } from "@/lib/audio"
import { Linkedin, Download } from "lucide-react"

export function Footer() {
  const { t } = useI18n()
  const { playClick, playHover } = useAudio()

  return (
    <footer className="bg-foreground text-background">
      {/* Main Footer Content */}
      <div className="px-4 md:px-8 py-12 md:py-16">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 md:gap-16">
            {/* Left Column - Brand */}
            <div>
              <h3 className="font-mono text-2xl md:text-3xl font-bold mb-4">
                GIULIA LAI
              </h3>
              <p className="font-sans text-sm md:text-base text-concrete leading-relaxed max-w-md">
                {t("bio.description")}
              </p>
            </div>

            {/* Right Column - Actions */}
            <div className="flex flex-col gap-4 md:items-end md:justify-center">
              {/* LinkedIn Button */}
              <a
                href="https://www.linkedin.com/in/-giulia-lai-/"
                target="_blank"
                rel="noopener noreferrer"
                onClick={playClick}
                onMouseEnter={playHover}
                className="inline-flex items-center gap-3 px-6 py-4 bg-accent text-foreground border-4 border-background font-bold transition-transform hover:translate-x-1 hover:translate-y-1"
              >
                <Linkedin className="w-5 h-5" />
                <span className="font-sans">{t("cta.action")}</span>
              </a>

              {/* Download CV Button */}
              <button
                onClick={playClick}
                onMouseEnter={playHover}
                className="inline-flex items-center gap-3 px-6 py-3 bg-background text-foreground border-4 border-background font-bold transition-transform hover:translate-x-1 hover:translate-y-1"
              >
                <Download className="w-5 h-5" />
                <span className="font-mono text-sm">{t("footer.download")}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Privacy Statement */}
      <div className="border-t-4 border-muted px-4 md:px-8 py-4">
        <p className="font-mono text-xs md:text-sm text-concrete text-center">
          {t("footer.privacy")}
        </p>
      </div>
    </footer>
  )
}
