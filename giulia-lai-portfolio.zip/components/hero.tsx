"use client"

import { useI18n } from "@/lib/i18n"
import { motion } from "framer-motion"

export function Hero() {
  const { t } = useI18n()

  return (
    <section className="relative min-h-screen flex items-center justify-center border-b-4 border-foreground industrial-grid">
      {/* Metal texture overlay */}
      <div className="absolute inset-0 metal-texture opacity-30 pointer-events-none" />
      
      <div className="relative z-10 max-w-5xl mx-auto px-4 md:px-8 py-32 text-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          {/* Main Title */}
          <h1 className="font-sans text-4xl md:text-6xl lg:text-7xl font-black uppercase tracking-tight mb-4">
            {t("hero.title")}
          </h1>
          
          {/* Subtitle */}
          <p className="font-mono text-xl md:text-2xl lg:text-3xl text-muted mb-12 tracking-wide">
            {t("hero.subtitle")}
          </p>
        </motion.div>

        {/* UVP Hammer */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="brutal-border bg-background p-6 md:p-10 max-w-3xl mx-auto"
        >
          <p className="font-sans text-lg md:text-xl lg:text-2xl font-bold leading-relaxed text-balance">
            {t("hero.uvp")}
          </p>
        </motion.div>

        {/* Decorative Lines */}
        <motion.div 
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="mt-16 flex items-center justify-center gap-4"
        >
          <div className="h-1 w-16 md:w-32 bg-foreground" />
          <div className="h-4 w-4 bg-accent rotate-45" />
          <div className="h-1 w-16 md:w-32 bg-foreground" />
        </motion.div>
      </div>
    </section>
  )
}
