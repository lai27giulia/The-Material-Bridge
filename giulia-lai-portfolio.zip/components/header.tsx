"use client"

import { useI18n } from "@/lib/i18n"
import { useAudio } from "@/lib/audio"
import { Volume2, VolumeOff } from "lucide-react"

export function Header() {
  const { language, setLanguage } = useI18n()
  const { isMuted, toggleMute, playClick } = useAudio()

  const handleLanguageChange = (lang: "es" | "en") => {
    playClick()
    setLanguage(lang)
  }

  const handleMuteToggle = () => {
    toggleMute()
    if (isMuted) {
      // Play click when unmuting to give feedback
      setTimeout(() => {
        const audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
        const oscillator = audioContext.createOscillator()
        const gainNode = audioContext.createGain()
        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)
        oscillator.type = "square"
        oscillator.frequency.setValueAtTime(600, audioContext.currentTime)
        gainNode.gain.setValueAtTime(0.05, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.1)
        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.1)
      }, 50)
    }
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b-4 border-foreground">
      <div className="flex items-center justify-between px-4 md:px-8 py-4">
        {/* Logo / Name */}
        <div className="flex items-center gap-4">
          <span className="font-mono text-lg md:text-xl font-bold tracking-tight">
            GIULIA LAI
          </span>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-4">
          {/* Audio Toggle */}
          <button
            onClick={handleMuteToggle}
            className="p-2 border-2 border-foreground hover:bg-foreground hover:text-background transition-colors"
            aria-label={isMuted ? "Enable audio" : "Disable audio"}
          >
            {isMuted ? (
              <VolumeOff className="w-5 h-5" />
            ) : (
              <Volume2 className="w-5 h-5" />
            )}
          </button>

          {/* Language Selector */}
          <div className="flex border-2 border-foreground">
            <button
              onClick={() => handleLanguageChange("es")}
              className={`px-3 py-1 font-mono text-sm font-bold transition-colors ${
                language === "es"
                  ? "bg-foreground text-background"
                  : "bg-background text-foreground hover:bg-muted hover:text-muted-foreground"
              }`}
            >
              ES
            </button>
            <button
              onClick={() => handleLanguageChange("en")}
              className={`px-3 py-1 font-mono text-sm font-bold border-l-2 border-foreground transition-colors ${
                language === "en"
                  ? "bg-foreground text-background"
                  : "bg-background text-foreground hover:bg-muted hover:text-muted-foreground"
              }`}
            >
              EN
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
