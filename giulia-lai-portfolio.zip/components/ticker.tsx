"use client"

import { useI18n } from "@/lib/i18n"

export function Ticker() {
  const { t } = useI18n()
  const tickerText = t("ticker.text")

  return (
    <div className="bg-foreground text-background overflow-hidden border-b-4 border-foreground">
      <div className="py-3 whitespace-nowrap">
        <div className="ticker-scroll inline-flex">
          {/* Repeat text multiple times for seamless scrolling */}
          {Array.from({ length: 4 }).map((_, i) => (
            <span key={i} className="font-mono text-sm md:text-base font-bold tracking-widest mx-8">
              {tickerText} •
            </span>
          ))}
          {Array.from({ length: 4 }).map((_, i) => (
            <span key={`dup-${i}`} className="font-mono text-sm md:text-base font-bold tracking-widest mx-8">
              {tickerText} •
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
