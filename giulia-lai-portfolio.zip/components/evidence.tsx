"use client"

import Image from "next/image"
import { useI18n } from "@/lib/i18n"
import { motion } from "framer-motion"

export function Evidence() {
  const { t } = useI18n()

  return (
    <section className="border-b-4 border-foreground bg-background">
      {/* Section Header */}
      <div className="border-b-4 border-foreground px-4 md:px-8 py-6">
        <h2 className="font-sans text-2xl md:text-4xl font-black uppercase tracking-tight">
          {t("evidence.title")}
        </h2>
        <p className="font-mono text-sm md:text-base text-muted mt-2">
          {t("evidence.subtitle")}
        </p>
      </div>

      {/* Images Grid */}
      <div className="grid md:grid-cols-2">
        {/* Micrograph */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="border-b-4 md:border-b-0 md:border-r-4 border-foreground"
        >
          <div className="p-4 md:p-6">
            <div className="brutal-border overflow-hidden bg-background">
              <div className="relative aspect-[4/3]">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/micrografia-FiAYId82RA2WXg9a07w5KyeQniLmAW.png"
                  alt="Metallographic micrograph showing grain structure with intergranular cracks"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-4 border-t-4 border-foreground bg-dirty-white">
                <p className="font-mono text-xs md:text-sm text-muted">
                  {t("evidence.micrograph")}
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Stress-Strain Diagram */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="p-4 md:p-6">
            <div className="brutal-border overflow-hidden bg-background">
              <div className="relative aspect-[4/3] bg-white">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/diagrammasd-KRYVe7UxHduSP9ZTczATZ7RDT9zNUe.png"
                  alt="Stress-strain curve showing Hooke's Law, yield point, ultimate strength, and fracture point"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4 border-t-4 border-foreground bg-dirty-white">
                <p className="font-mono text-xs md:text-sm text-muted">
                  {t("evidence.diagram")}
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
