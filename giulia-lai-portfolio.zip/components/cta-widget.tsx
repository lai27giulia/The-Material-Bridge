"use client"

import { useI18n } from "@/lib/i18n"
import { useAudio } from "@/lib/audio"
import { Linkedin } from "lucide-react"
import { motion } from "framer-motion"

export function CTAWidget() {
  const { t } = useI18n()
  const { playClick, playHover } = useAudio()

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, delay: 1 }}
      className="fixed bottom-4 right-4 md:bottom-8 md:right-8 z-40"
    >
      <a
        href="https://www.linkedin.com/in/-giulia-lai-/"
        target="_blank"
        rel="noopener noreferrer"
        onClick={playClick}
        onMouseEnter={playHover}
        className="group block"
      >
        <div className="bg-accent border-4 border-foreground shadow-[8px_8px_0_0_#000000] p-4 md:p-5 transition-transform hover:translate-x-1 hover:translate-y-1 hover:shadow-[4px_4px_0_0_#000000]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-foreground text-background">
              <Linkedin className="w-5 h-5 md:w-6 md:h-6" />
            </div>
            <div className="text-left">
              <p className="font-mono text-xs md:text-sm font-bold text-foreground uppercase">
                {t("cta.question")}
              </p>
              <p className="font-sans text-sm md:text-base font-black text-foreground glitch-text">
                {t("cta.action")}
              </p>
            </div>
          </div>
        </div>
      </a>
    </motion.div>
  )
}
