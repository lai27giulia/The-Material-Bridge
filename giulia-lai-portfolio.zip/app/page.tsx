"use client"

import { I18nProvider } from "@/lib/i18n"
import { AudioProvider } from "@/lib/audio"
import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { CaseStudy } from "@/components/case-study"
import { Evidence } from "@/components/evidence"
import { Ticker } from "@/components/ticker"
import { Bio } from "@/components/bio"
import { Footer } from "@/components/footer"
import { CTAWidget } from "@/components/cta-widget"

export default function Home() {
  return (
    <I18nProvider>
      <AudioProvider>
        <div className="min-h-screen bg-background">
          <Header />
          
          <main className="pt-16">
            <Hero />
            <CaseStudy />
            <Evidence />
            <Ticker />
            <Bio />
          </main>

          <Footer />
          <CTAWidget />
        </div>
      </AudioProvider>
    </I18nProvider>
  )
}
